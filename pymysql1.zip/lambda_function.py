import pymysql
endpoint = 'aws-mock-db.cluster-csaruqlxxway.us-east-1.rds.amazonaws.com'
username = 'admin'
password = 'Password'
database_name = 'fantasyleague'
 
#Connection
connection = pymysql.connect(endpoint, user=username,
	passwd=password, db=database_name)
 
def lambda_handler(event, context):
	cursor = connection.cursor()
	return "hello"
